import 'package:flutter/material.dart';

void main() {

  runApp( MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pink,
        title: Text("MedAlert", style:TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
      ),
      // body:Center(child: Text("Yesha", style: TextStyle(fontWeight: FontWeight.w900,fontSize: 30),),)

      // body: ElevatedButton(onPressed: () {print("Yesha selected");}, child: Text("Yesha")
      // ),
        // TextButton(onPressed: () {}, child: Icon(Icons.add_a_photo)),
        // FloatingActionButton(onPressed: (){}, child: Icon(Icons.add),),

      body: Column(
         mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                // height: 60,
                // width: 180,
                color: Colors.pink,
                child: Text("row1col1",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w900),),
              ),

              Container(
                // height: 60,
                // width: 180,
                color: Colors.pink,
                child: Text("row1col2",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w900),),
              ),

              Container(
                // height: 60,
                // width: 180,
                color: Colors.pink,
                child: Text("row1col3",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w900),),
              )
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                // height: 60,
                // width: 180,
                color: Colors.pinkAccent,
                child: Text("row2col1",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w900),),
              ),

              Container(
                // height: 60,
               // width: 180,
                color: Colors.pinkAccent,
                child: Text("row2col2",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w900),),
              ),

              Container(
                // height: 60,
                // width: 180,
                color: Colors.pinkAccent,
                child: Text("row2col3",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w900),),
              )
            ],
          ),

          Row(
             mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                // height: 60,
                // width: 180,
                color: Colors.pinkAccent,
                child: Text("row3col1",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w900),),
              ),

              Container(
                // height: 60,
                // width: 180,
                color: Colors.pinkAccent,
                child: Text("row3col2",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w900),),
              ),

              Container(
                // height: 60,
                // width: 180,
                color: Colors.pinkAccent,
                child: Text("row3col3",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w900),),
              )
            ],
          )


        ],
      ),

    floatingActionButton: FloatingActionButton(onPressed: (){},child: Icon(Icons.add),backgroundColor: Colors.pink,),

    ),
  ));
}

